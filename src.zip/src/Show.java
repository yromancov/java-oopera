import javax.naming.NamingEnumeration;
import java.util.ArrayList;
import java.util.HashMap;

public class Show {
    ArrayList<Actor> actors = new ArrayList<>();
    HashMap<Show, ArrayList<Actor>> actorShow = new HashMap<>();
    public void addActors(Actor actor) {

        if (actors.contains(actor)) {
            System.out.println("Такой актер уже есть в команде");
            return;
        }

        actors.add(actor);
        System.out.println("Добавлен новый актер!");
    }


    public void printActorsShow() {
        for (Actor actor : actors) {
            System.out.println(actor.getName() + " " + actor.getSurname() + " (" + actor.getHeight() + ")");
        }
    }

    public void changeActors(String surname, Actor actor){
        if(!actors.contains(surname)){
            System.out.println("Данного актера не существует!");
            return;
        }
        for (Actor actorForRemove: actors){
            if (actorForRemove.getSurname().equals(surname)){
                actors.remove(actorForRemove);
                actors.add(actor);
                System.out.println("Актер успешно заменен");
            }
        }
    }
}
