public class Balet extends MusicalShow {

    private String choreographer;

    public Balet(MusicalShow musicalShow, String choreographer) {
        super(musicalShow.getMusicAuthor(), musicalShow.getLibrettoText());
        this.choreographer = choreographer;
    }

    public String getChoreographer() {
        return choreographer;
    }

    public void setChoreographer(String choreographer) {
        this.choreographer = choreographer;
    }

    @Override
    public void printLibretto() {
        super.printLibretto();
    }
}
